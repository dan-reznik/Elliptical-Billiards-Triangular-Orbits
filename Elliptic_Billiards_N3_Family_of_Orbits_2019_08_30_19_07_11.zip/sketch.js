let g_width = 800;
let g_height = 600;

// DRAW

function draw_line([frx, fry], [tox, toy], rgb) {
  push();
  stroke(rgb);
  strokeWeight(0.01);
  line(frx, fry, tox, toy);
  pop();
}

function draw_axes(a) {
  push();
  strokeWeight(0.0125);
  line(-a, 0, a, 0);
  line(0, -1, 0, 1);
  pop();
}

function draw_point([x, y], rgb) {
  push();
  fill(rgb);
  strokeWeight(0);
  circle(x, y, 0.05);
  pop();
}

function draw_text(txt, p, rgb) {
  push();
  textSize(0.1);
  strokeWeight(0);
  fill(rgb);
  textAlign(CENTER, BOTTOM);
  textStyle(NORMAL);
  text(txt, p[0], p[1] - 0.02);
  pop();
}

// DRAW BILLIARD

function draw_center() {
  draw_point([0, 0], [150, 0, 0])
}

function draw_boundary(a) {
  push();
  strokeWeight(0.0125);
  ellipse(0, 0, 2 * a, 2)
  pop();
}

function draw_circle_low([cx,cy],r,rgb) {
  push();
  stroke(rgb);
  strokeWeight(0.0125);
  noFill();
  circle(cx, cy, 2*r);
  draw_point([cx,cy], rgb)
  pop();
}

function draw_billiard(a) {
  draw_boundary(a);
  draw_axes(a);
  //draw_center();
}

function draw_tri([p1, p2, p3], rgb, wgt = 0.015) {
  push();
  stroke(rgb);
  strokeWeight(wgt);
  noFill();
  triangle(p1[0], p1[1], p2[0], p2[1], p3[0], p3[1]);
  pop();
}

function draw_normal(p, n, lgt) {
  draw_line(p, ray(p, n, lgt), [0, 0, 0]);
}

// ELLIPTIC BILLIARD

function ellInterRay(a, [x, y], [nx, ny]) {
  let a2 = a * a;
  let c2 = nx * nx + a2 * ny * ny;
  let c1 = 2 * (nx * x + a2 * ny * y);
  let c0 = x * x + a2 * (y * y - 1);
  let ss = quadRoots(c2, c1, c0);
  return ray([x, y], [nx, ny], ss[1]);
}

function ell_norm(a, [x, y]) {
  return normalize([-x, -y * a * a]);
}

function cos_alpha(a, x) {
  let a2 = a * a;
  let a4 = a2 * a2;
  delta = sqrt(a4 - a2 + 1);
  let num = a2 * sqrt(2 * delta - a2 - 1);
  let denom = (a2 - 1) * sqrt(a4 - (a2 - 1) * x * x);
  return num / denom;
}

// ORBITS

function orbit_normals(a, tDeg) {
  let t = toRad(tDeg);
  let p1 = [a * cos(t), sin(-t)];
  let n1 = ell_norm(a, p1);
  let ca = cos_alpha(a, p1[0]);
  let sa = sqrt(1 - ca * ca);
  let nrot = rot(n1, sa, ca);
  let nrotNeg = rot(n1, -sa, ca);
  let p2 = ellInterRay(a, p1, nrot);
  let p3 = ellInterRay(a, p1, nrotNeg);
  let n2 = ell_norm(a, p2);
  let n3 = ell_norm(a, p3);
  let obj = {
    o: [p1, p2, p3],
    n: [n1, n2, n3],
    s: tri_sides([p1, p2, p3])
  };
  return obj;
}

function draw_orbit(ons) {
  const lgt = 0.2;
  push();
  draw_tri(ons.o, [0, 0, 200])
  for (let i = 0; i < 3; i++) {
    draw_normal(ons.o[i], ons.n[i], lgt);
    draw_point(ons.o[i], i == 0 ? [150, 0, 0] : [0, 0, 0]);
  }
  pop();
}

// MAIN

let g_loop = true;
let g_tDeg = 0;
let g_a = 1.5;
let g_locus_X1 = [];
let g_locus_X2 = [];
let g_locus_X3 = [];
let g_locus_X4 = [];
let g_locus_X5 = [];
let g_locus_X6 = [];
let g_locus_X7 = [];
let g_locus_X8 = [];
let g_locus_X10 = [];
let g_locus_X11 = [];
let g_locus_X12 = [];
let g_locus_X15 = [];
let g_locus_X40 = [];
//let g_locus_X88 = [];
let g_locus_X99 = [];
//let g_locus_X100 = [];
let g_locus_X142 = [];
let g_locus_X144 = [];
let g_locus_X173 = [];

clr_brown = [102, 102, 0];
clr_gray = [100,100,100];
clr_dark_red = [150, 0, 0];
clr_dark_green = [0, 150, 0];
clr_light_blue = [0, 204, 204];
clr_purple = [155, 20, 147];
clr_pink = [255, 20, 147];

let g_locus_symmedial_vtx = [];
let g_locus_medial_vtx = [];
let g_locus_feuerbach_vtx = [];
let g_locus_anticompl_vtx = [];
let g_locus_excentral_vtx = [];
let g_locus_intouch_vtx = [];
let g_locus_extouch_vtx = [];

function create_loci() {
  let tDegStep = 1,
    tDegMax = 142;
  for (let tDeg = 0; tDeg < tDegMax; tDeg += tDegStep) {
    let ons = orbit_normals(g_a, tDeg);
    g_locus_X1.push(trilin_X1(ons.o, ons.s));
    g_locus_X2.push(trilin_X2(ons.o, ons.s));
    g_locus_X3.push(trilin_X3(ons.o, ons.s));
    g_locus_X4.push(trilin_X4(ons.o, ons.s));
    g_locus_X5.push(trilin_X5(ons.o, ons.s));
    g_locus_X6.push(trilin_X6(ons.o, ons.s));
    g_locus_X7.push(trilin_X7(ons.o, ons.s));
    g_locus_X8.push(trilin_X8(ons.o, ons.s));
    g_locus_X10.push(trilin_X10(ons.o, ons.s));
    g_locus_X11.push(trilin_X11(ons.o, ons.s));
    g_locus_X12.push(trilin_X12(ons.o, ons.s));
    g_locus_X15.push(trilin_X15(ons.o, ons.s));
    g_locus_X40.push(trilin_X40(ons.o, ons.s));
    g_locus_X99.push(trilin_X99(ons.o, ons.s));
    //g_locus_X88.push(trilin_X88(ons.s,ons.o));
    //g_locus_X100.push(trilin_X100(ons.s,ons.o));
    g_locus_X142.push(trilin_X142(ons.o, ons.s));
    g_locus_X144.push(trilin_X144(ons.o, ons.s));
    g_locus_X173.push(trilin_X173(ons.o, ons.s));
  }
  // those which require all the way to 360
  for (let tDeg = 0; tDeg <= 360; tDeg += tDegStep) {
    let ons = orbit_normals(g_a, tDeg);
    g_locus_symmedial_vtx.push(symmedial_vtx(ons.o, ons.s));
    g_locus_medial_vtx.push(medial_vtx(ons.o, ons.s));
    g_locus_feuerbach_vtx.push(feuerbach_vtx(ons.o, ons.s));
    g_locus_anticompl_vtx.push(anticompl_vtx(ons.o, ons.s));
    g_locus_excentral_vtx.push(excentral_vtx(ons.o, ons.s));
    g_locus_intouch_vtx.push(intouch_vtx(ons.o, ons.s));
    g_locus_extouch_vtx.push(extouch_vtx(ons.o, ons.s));
  }
}

function create_checkboxes() {
  let xstep = 70, ystep = 30;
  
  let y = 0;
  chk_x1234 = createCheckbox('X1-4*', false);
  chk_x1234.position(xstep * 0, y);
  chk_euler = createCheckbox('Euler', false);
  chk_euler.position(xstep * 1, y);
  
  y+=ystep;
  chk_incircle = createCheckbox('Incirc', false);
  chk_incircle.position(xstep * 0, y);
  chk_circum = createCheckbox('Circum', false);
  chk_circum.position(xstep * 1, y);
  chk_npc = createCheckbox('9-Pt', false);
  chk_npc.position(xstep * 2, y);
  
  y+=ystep;
  chk_x5 = createCheckbox('X5*', false);
  chk_x5.position(xstep * 0, y);
  //chk_x5.style("color", "#FFFFFF");
  chk_x6 = createCheckbox('X6~', false);
  chk_x6.position(xstep * 1, y);
  chk_x7 = createCheckbox('X7*', false);
  chk_x7.position(xstep * 2, y);
  chk_x8 = createCheckbox('X8', false);
  chk_x8.position(xstep * 3, y);
  
  y+=ystep;
  chk_x10 = createCheckbox('X10*', false);
  chk_x10.position(xstep * 0, y);
  chk_x11 = createCheckbox('X11*', false);
  chk_x11.position(xstep * 1, y);
  chk_x12 = createCheckbox('X12', false);
  chk_x12.position(xstep * 2, y);
  chk_x15 = createCheckbox('X15~', false);
  chk_x15.position(xstep * 3, y);
  
  y+=ystep;
  chk_x40 = createCheckbox('X40*', false);
  chk_x40.position(xstep * 0, y);
  chk_x88 = createCheckbox('X88*', false);
  chk_x88.position(xstep * 1, y);
  chk_x99 = createCheckbox('X99~', false);
  chk_x99.position(xstep * 2, y);
  chk_x100 = createCheckbox('X100*', false);
  chk_x100.position(xstep * 3, y);
  
  y+=ystep;
  chk_x142 = createCheckbox('X142*', false);
  chk_x142.position(xstep * 0, y);
  chk_x144 = createCheckbox('X144*', false);
  chk_x144.position(xstep * 1, y);
  chk_x173 = createCheckbox('X173', false);
  chk_x173.position(xstep * 2, y);
  //chk_x7.style("color", "#FFFFFF");
  
  y+=ystep;
  chk_x1p = createCheckbox('ΔInt', false);
  chk_x1p.position(xstep * 0, y);
  chk_ext = createCheckbox('ΔExt', false);
  chk_ext.position(xstep * 1, y);
  chk_exc = createCheckbox('ΔExc', false);
  chk_exc.position(xstep * 2, y);
  
  y+=ystep;
  chk_medial = createCheckbox('ΔMed', false);
  chk_medial.position(xstep * 0, y);
  chk_anticompl = createCheckbox('ΔAct', false);
  chk_anticompl.position(xstep * 1, y);
  chk_feu = createCheckbox('ΔFeu', false);
  chk_feu.position(xstep * 2, y);
  
  y+=ystep;
  y+=ystep;
  chk_x15p = createCheckbox('ΔX15p', false);
  chk_x15p.position(xstep * 0, y);
  chk_symmedial = createCheckbox('ΔSym', false);
  chk_symmedial.position(xstep * 1, y);
  // for CSS
  let all_chks = [chk_x1234, chk_x5, chk_x6, chk_x7, chk_x8,
    chk_x10, chk_x11, chk_x12, chk_x15, chk_x40,
    chk_x100, chk_x88, chk_x99, chk_x100, chk_x142,
    chk_x144, chk_x173, chk_euler, chk_x1p, chk_ext, chk_x15p,
    chk_exc, chk_medial, chk_anticompl, chk_feu, chk_symmedial
  ];
  all_chks.map(c => c.class('chk'));
}

function setup() {
  create_checkboxes();
  canvas = createCanvas(g_width, g_height);
  //frameRate(15);
  create_loci();
}

function draw_locus(locus, ons, xnum, trilin_fn, rgb) {
  push();
  strokeWeight(0.01);
  stroke(rgb);
  for (let i = 0; i < locus.length - 1; i++)
    line(locus[i][0], locus[i][1], locus[i + 1][0], locus[i + 1][1]);
  let xn = trilin_fn(ons.o, ons.s);
  draw_point(xn, rgb);
  draw_text('X' + xnum, xn, rgb);
  pop();
}

function draw_labeled_point(ons, xnum, trilin_fn, rgb) {
  push();
  strokeWeight(0.01);
  stroke(rgb);
  let xn = trilin_fn(ons.o, ons.s);
  draw_point(xn, rgb);
  draw_text('X' + xnum, xn, rgb);
  pop();
}

function get_tri_centroid([v1, v2, v3]) {
  return [(v1[0] + v2[0] + v3[0]) / 3, (v1[1] + v2[1] + v3[1]) / 3];
}

function draw_pedal_x15(ons, rgb) {
  t15 = trilin_x15_raw(ons.s);
  let pedal = pedal_triangle(t15, ons.o, ons.s);
  draw_tri(pedal, rgb, wgt = 0.01);
  let g = get_tri_centroid(pedal);
  draw_point(g, rgb);
}

function draw_generic_triangle(ons, rgb, tri_fn) {
  let tri = tri_fn(ons.o, ons.s);
  draw_tri(tri, rgb, wgt = 0.01);
  tri.map(v => draw_point(v, rgb));
}

function draw_intouch(ons, rgb) {
  draw_generic_triangle(ons, rgb, intouch_triangle);
}

function draw_feuerbach(ons, rgb) {
  draw_generic_triangle(ons, rgb, feuerbach_triangle);
}

function draw_excentral(ons, rgb) {
  draw_generic_triangle(ons, rgb, excentral_triangle);
}

function draw_medial(ons, rgb) {
  draw_generic_triangle(ons, rgb, medial_triangle);
}

function draw_extouch(ons, rgb) {
  draw_generic_triangle(ons, rgb, extouch_triangle);
}

function draw_anticompl(ons, rgb) {
  draw_generic_triangle(ons, rgb, anticompl_triangle);
}

function draw_symmedial(ons, rgb) {
  draw_generic_triangle(ons, rgb, symmedial_triangle);
}

function draw_euler_line(ons, rgb) {
  let x3 = trilin_X3(ons.o, ons.s);
  let x4 = trilin_X4(ons.o, ons.s);
  draw_line(x3, x4, rgb);
}

function draw_circle(ons,trilin_fn,vtx_fn,rgb) {
  let ctr = trilin_fn(ons.o,ons.s);
  let vtx = vtx_fn(ons.o,ons.s);
  let rad = edist(ctr, vtx);
  draw_circle_low(ctr,rad,rgb);
}

function draw() {
  background(255, 255, 255);
  let ons = orbit_normals(g_a, g_tDeg);
  push();
  translate(g_width / 2, g_height / 2);
  scale(g_width / 6);
  draw_billiard(g_a);
  draw_orbit(ons);
  draw_labeled_point(ons, 9, trilin_X9, [200, 0, 0]);
  //experimental: mitten of excentral's extangents tri
  //draw_labeled_point(ons,999,trilin_X9_ext_exc,[40,80,120]);
  draw_text('© 2019 Dan S. Reznik', [1.35, 1.65], [0, 0, 0]);
  if(chk_incircle.checked())
    draw_circle(ons,trilin_X1,intouch_vtx,clr_dark_green);
  if(chk_circum.checked())
    draw_circle(ons,trilin_X3,(o,s)=>ons.o[0],clr_purple);
  if(chk_npc.checked())
    draw_circle(ons,trilin_X5,medial_vtx,clr_pink);
  if (chk_x1234.checked()) {
    draw_locus(g_locus_X1, ons, 1, trilin_X1, clr_dark_green);
    draw_locus(g_locus_X2, ons, 2, trilin_X2, [139, 69, 19]);
    draw_locus(g_locus_X3, ons, 3, trilin_X3, clr_purple);
    draw_locus(g_locus_X4, ons, 4, trilin_X4, [255, 165, 0]);
  }

  if (chk_x5.checked())
    draw_locus(g_locus_X5, ons, 5, trilin_X5, clr_pink);
  if (chk_x6.checked())
    draw_locus(g_locus_X6, ons, 6, trilin_X6, [100, 100, 200]);
  if (chk_x7.checked())
    draw_locus(g_locus_X7, ons, 7, trilin_X7, [155, 165, 0]);
  if (chk_x8.checked())
    draw_locus(g_locus_X8, ons, 8, trilin_X8, [50, 50, 100]);
  if (chk_x10.checked())
    draw_locus(g_locus_X10, ons, 10, trilin_X10, [100, 50, 50]);
  if (chk_x7.checked())
    draw_locus(g_locus_X7, ons, 7, trilin_X7, [155, 165, 0]);
  if (chk_x11.checked())
    draw_locus(g_locus_X11, ons, 11, trilin_X11, [150, 150, 20]);
  if (chk_x12.checked())
    draw_locus(g_locus_X12, ons, 12, trilin_X12, [250, 100, 50]);
  if (chk_x15.checked())
    draw_locus(g_locus_X15, ons, 15, trilin_X15, [150, 0, 50]);
  if (chk_x40.checked())
    draw_locus(g_locus_X40, ons, 40, trilin_X40, [20, 20, 255]);
  if (chk_x88.checked())
    draw_labeled_point(ons, 88, trilin_X88, [0, 0, 0]);
  if (chk_x99.checked())
    draw_locus(g_locus_X99, ons, 99, trilin_X99, [100, 100, 100]);
  if (chk_x100.checked())
    draw_labeled_point(ons, 100, trilin_X100, [0, 0, 0]);
  if (chk_x142.checked())
    draw_locus(g_locus_X142, ons, 142, trilin_X142, [100, 0, 100]);
  if (chk_x144.checked())
    draw_locus(g_locus_X144, ons, 144, trilin_X144, [0, 100, 100]);
  if (chk_x173.checked())
    draw_locus(g_locus_X173, ons, 173, trilin_X173, [100, 250, 50]);
   if (chk_ext.checked()) {
     draw_extouch(ons, clr_gray);
     draw_locus(g_locus_extouch_vtx, ons, "ext", extouch_vtx, clr_gray);
   }
  if (chk_euler.checked())
    draw_euler_line(ons, [100, 100, 100]);
  if (chk_x1p.checked()) {
    draw_intouch(ons, clr_dark_green);
    draw_locus(g_locus_intouch_vtx, ons, "int", intouch_vtx, clr_dark_green);
  }
  if (chk_x15p.checked())
    draw_pedal_x15(ons, [150, 0, 50]);
  if (chk_exc.checked()) {
    draw_excentral(ons, clr_dark_green);
    draw_locus(g_locus_excentral_vtx, ons, "exc", excentral_vtx, clr_dark_green);
  }
  if (chk_medial.checked()) {
    draw_medial(ons, clr_dark_red);
    draw_locus(g_locus_medial_vtx, ons, "feu", feuerbach_vtx, clr_dark_red);
  }
  if (chk_anticompl.checked()) {
    draw_anticompl(ons, clr_light_blue);
    draw_locus(g_locus_anticompl_vtx, ons, "act", anticompl_vtx, clr_light_blue);
  }
  if (chk_feu.checked()) {
    draw_feuerbach(ons, clr_brown);
    draw_locus(g_locus_feuerbach_vtx, ons, "feu", feuerbach_vtx, clr_brown);
  }
  if (chk_symmedial.checked()) {
    draw_symmedial(ons, [100, 100, 200]);
    draw_locus(g_locus_symmedial_vtx, ons, "6v", symmedial_vtx, [100, 100, 200]);
  }
  pop();

  g_tDeg += 0.125;
}

function mousePressed() {
  let click_ok = abs(mouseX - g_width / 2) < g_width / 4 && abs(mouseY - g_height / 2) < g_height / 4;
  if (click_ok && g_loop) {
    noLoop();
    g_loop = !g_loop;
  } else if (click_ok) {
    loop();
    g_loop = !g_loop;
  }
}