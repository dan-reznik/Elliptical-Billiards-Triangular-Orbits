// MATH UTILS

function toRad(tDeg) {
  return tDeg * PI / 180;
}

function law_of_cosines(a,b,c) {
  return (b*b+c*c-a*a)/(2*b*c);
}

function sum(v) {
  let acc=0;
  for(let i=0;i<v.length;i++)
    acc+=v[i];
  return acc;
}

function dot(v,u) {
  let acc=0;
  for(let i=0;i<v.length;i++)
    acc+=v[i]*u[i];
  return acc;
}

function quadRoots(a, b, c) {
  let det = sqrt(b * b - 4 * a * c);
  return [(-b - det) / (2 * a), (-b + det) / (2 * a)];
}

function ray(p0, phat, d) {
  return [p0[0] + phat[0] * d, p0[1] + phat[1] * d];
}

function rot([x, y], st, ct) {
  return [ct * x - st * y, st * x + ct * y];
}

function edist(p1, p2) {
  let dx = p1[0] - p2[0];
  let dy = p1[1] - p2[1];
  return sqrt(dx * dx + dy * dy);
}

function normalize([x, y]) {
  let magn = sqrt(x * x + y * y);
  return [x / magn, y / magn];
}

function tri_sides([p1,p2,p3]) {
  let s1 = edist(p2, p3);
  let s2 = edist(p3, p1);
  let s3 = edist(p1, p2);
  return [s1,s2,s3];
}

function tri_cosines([a,b,c]) {
  let x=law_of_cosines(a,b,c);
  let y=law_of_cosines(b,c,a);
  let z=law_of_cosines(c,a,b);
  return [x,y,z];
}