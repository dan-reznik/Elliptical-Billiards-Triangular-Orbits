// TRILINEARS

function trilin_to_cartesian(
  [A, B, C], //(* vertices *)
  [a, b, c], // (* side lengths *)
  [x, y, z]) //(* trilinears *)
{
  //let denom = a * x + b * y + c * z;
  let v = [a*x,b*y,c*z];
  let denom = sum(v);
  return [dot(v,[A[0],B[0],C[0]])/denom,
          dot(v,[A[1],B[1],C[1]])/denom];
}

function trilin_cyclic(orbit,fn,[a,b,c]) {
  tris = [fn(a,b,c),fn(b,c,a),fn(c,a,b)];
  return trilin_to_cartesian(orbit, [a,b,c], tris);
}

function trilin_X1(orbit, sides) {
  return trilin_to_cartesian(orbit, sides, [1, 1, 1]);
}

function trilin_X2(orbit,[a,b,c]) {
  return trilin_to_cartesian(orbit,[a,b,c],[1/a,1/b,1/c]);
}

function trilin_X3(orbit,[a,b,c]) {
  let cyclic = function(a,b,c) {
    let a2=a*a,b2=b*b,c2=c*c;
    return a*(b2+c2-a2);
  }
  return trilin_cyclic(orbit,cyclic,[a,b,c]);
}

function trilin_X4(orbit,[a,b,c]) {
    let cyclic = function(a,b,c) {
    let a2=a*a,b2=b*b,c2=c*c;
    return  1/(b2+c2-a2)/a;
  }
  return trilin_cyclic(orbit,cyclic,[a,b,c]);
}

function trilin_X5(orbit, [a,b,c]) {
  let cyclic = function(a,b,c) {
    let a2=a*a,b2=b*b,c2=c*c;
    return b*c*(a2*(b2+c2)-(b2-c2)*(b2-c2));
  }
  return trilin_cyclic(orbit,cyclic,[a,b,c]);
}

function trilin_X6(orbit,[a,b,c]) {
  return trilin_to_cartesian(orbit,[a,b,c],[a,b,c]);
}

function trilin_X7(orbit, [a,b,c]) {
  let cyclic = function(a,b,c) {
    return b*c/(b+c-a);
  }
  return trilin_cyclic(orbit,cyclic,[a,b,c]);
} 

function trilin_X8(orbit, [a,b,c]) {
  let cyclic = function(a,b,c) {
    return (b+c-a)/a;
  }
  return trilin_cyclic(orbit,cyclic,[a,b,c]);
}

function trilin_X9(orbit, [a,b,c]) {
  let cyclic = function(a,b,c) {
    return b+c-a;
  }
  return trilin_cyclic(orbit,cyclic,[a,b,c]);
}

function trilin_X10(orbit, [a,b,c]) {
  let cyclic = function(a,b,c) {
    return b*c*(b+c) ;
  }
  return trilin_cyclic(orbit,cyclic,[a,b,c]);
}

function trilin_X11(orbit, [a,b,c]) {
  let cyclic = function(a,b,c) {
    return b*c*(b+c-a)*(b-c)*(b-c);
  }
  return trilin_cyclic(orbit,cyclic,[a,b,c]);
}

function trilin_X12(orbit, [a,b,c]) {
  let cyclic = function(a,b,c) {
    return b*c*(b+c)*(b+c)/(b+c-a);
  }
  return trilin_cyclic(orbit,cyclic,[a,b,c]);
}

function trilin_X40(orbit, [a,b,c]) {
  let cyclic = function(a,b,c) {
    return b/(c+a-b)+c/(a+b-c)-a/(b+c-a);
  }
  return trilin_cyclic(orbit,cyclic,[a,b,c]);
}

function trilin_X88(orbit, [a,b,c]) {
  let cyclic = function(a,b,c) {
    return 1/(b+c-2*a);
  }
  return trilin_cyclic(orbit,cyclic,[a,b,c]);
} 

function trilin_X99(orbit, [a,b,c]) {
  let cyclic = function(a,b,c) {
    return b*c/(b*b - c*c);
  }
  return trilin_cyclic(orbit,cyclic,[a,b,c]);
} 

function trilin_X100(orbit, [a,b,c]) {
  let cyclic = function(a,b,c) {
    return 1/(b-c);
  }
  return trilin_cyclic(orbit,cyclic,[a,b,c]);
} 

function trilin_X142(orbit, [a,b,c]) {
  let cyclic = function(a,b,c) {
    let bc2=(b-c)*(b-c);
    return b+c-bc2/a;
  }
  return trilin_cyclic(orbit,cyclic,[a,b,c]);
} 

function trilin_X144(orbit, [a,b,c]) {
  let cyclic = function(a,b,c) {
    return 1/(a-b-c)+1/(a-b+c)+1/(a+b-c);
  }
  return trilin_cyclic(orbit,cyclic,[a,b,c]);
}

// clawson of excentral
function trilin_X173(orbit, sides) {
  let cyclic = function(a,b,c) {
    return 1/(b*b+c*c-a*a);
  }
  let exc = excentral_triangle(orbit,sides);
  let excSides=tri_sides(exc);
  return trilin_cyclic(exc,cyclic,excSides);
}


let g_never = true;

// mitten of extangents of excentral
function trilin_X9_ext_exc(orbit, sides) {
  let exc = excentral_triangle(orbit,sides);
  let exc_sides=tri_sides(exc);
  let ext = extangents_triangle(exc,exc_sides);
  let ext_sides=tri_sides(ext);
  let x9_ext_exc = trilin_X9(ext, ext_sides);
  if(g_never) {
    g_never=false;
    console.log({ext:ext,ext_sides:ext_sides,x9:x9_ext_exc});
  }
  return x9_ext_exc;
}

function trilin_x15_raw([a,b,c]) {
  let s3=sqrt(3);
  let [cosA,cosB,cosC]=tri_cosines([a,b,c]);
  let sinA=sqrt(1-cosA*cosA);
  let sinB=sqrt(1-cosB*cosB)
  let sinC=sqrt(1-cosC*cosC);
  let alpha=3*cosA+s3*sinA;
  let beta =3*cosB+s3*sinB;
  let gamma=3*cosC+s3*sinC;
  return [alpha,beta,gamma];
}

function trilin_X15(orbit,sides) {
  let t15 = trilin_x15_raw(sides);
  return trilin_to_cartesian(orbit,sides,t15);
} 

function generic_triangle(orbit,sides,ts) {
  return ts.map(t=>trilin_to_cartesian(orbit,sides,t));
}

function pedal_triangle([alpha,beta,gamma],
                         orbit,[a,b,c]) {
  let cosA=law_of_cosines(a,b,c);
  let cosB=law_of_cosines(b,c,a);
  let cosC=law_of_cosines(c,a,b);
  let t1=[0,beta+alpha*cosC,gamma+alpha*cosB];
  let t2=[alpha+beta*cosC,0,gamma+beta*cosA];
  let t3=[alpha+gamma*cosB,beta+gamma*cosA,0];
  return generic_triangle(orbit,[a,b,c],[t1,t2,t3]);
}

// http://mathworld.wolfram.com/ExtangentsTriangle.html
function extangents_triangle(orbit,sides) {
  let [x,y,z]=tri_cosines(sides);
  let m=[
    [-x-1,x+z,x+y],
    [y+z,-y-1,y+x],
    [z+y,z+x,-z-1]
    ];
  return generic_triangle(orbit,sides,m);
}

function excentral_triangle(orbit,sides) {
  let ts=[[-1,1,1],[1,-1,1],[1,1,-1]];
  return generic_triangle(orbit,sides,ts);
}

function medial_triangle(orbit,[a,b,c]) {
  let ts=[[0,1/b,1/c],[1/a,0,1/c],[1/a,1/b,0]];
  return generic_triangle(orbit,[a,b,c],ts);
}

function anticompl_triangle(orbit,[a,b,c]) {
  let ts=[[-1/a,1/b,1/c],[1/a,-1/b,1/c],[1/a,1/b,-1/c]];
  return generic_triangle(orbit,[a,b,c],ts);
}

function feuerbach_triangle(orbit,sides) {
  let [cA,cB,cC]=tri_cosines(sides);
  let sA=sqrt(1-cA*cA);
  let sB=sqrt(1-cB*cB)
  let sC=sqrt(1-cC*cC);
 
  let f11 = /* -s2[(b-c)/2] = [cos(b-c)-1]/2 */ (cB*cC + sB*sC - 1)/2;
  let f22 = /* -s2[(c-a)/2] = [cos(c-a)-1]/2 */ (cC*cA + sC*sA - 1)/2; 
  let f33 = /* -s2[(a-b)/2] = [cos(a-b)-1]/2 */ (cA*cB + sA*sB - 1)/2;
  let f21 = /*  c2[(b-c)/2] = [cos(b-c)+1]/2 */ (cB*cC + sB*sC + 1)/2;
  let f12 = /*  c2[(c-a)/2] = [cos(c-a)+1]/2 */ (cC*cA + sC*sA + 1)/2;
  let f13 = /*  c2[(a-b)/2] = [cos(a-b)+1]/2 */ (cA*cB + sA*sB + 1)/2;
  
  ts=[[f11,f12,f13],
      [f21,f22,f13],
      [f21,f12,f33]];
  
  return generic_triangle(orbit,sides,ts);
}

function symmedial_triangle(orbit,[a,b,c]) {
  let ts=[[0,b,c],[a,0,c],[a,b,0]];
  return generic_triangle(orbit,[a,b,c],ts);
}

function extouch_triangle(orbit,[a,b,c]) {
  let ts=[[0,(a-b+c)/b,(a+b-c)/c],
          [(-a+b+c)/a,0,(a+b-c)/c],
          [(-a+b+c)/a,(a-b+c)/b,0]];
  return generic_triangle(orbit,[a,b,c],ts);
}

function intouch_triangle(orbit,[a,b,c]) {
  let ts=[[0,            (a*c)/(a-b+c),(a*b)/(a+b-c)],
          [(b*c)/(b-a+c),0            ,(a*b)/(a+b-c)],
          [(b*c)/(b-a+c),(a*c)/(a-b+c),0            ]];
  return generic_triangle(orbit,[a,b,c],ts);
}

function intouch_vtx(orbit,[a,b,c]) {
  let t=[0,(a*c)/(a-b+c),(a*b)/(a+b-c)];
  return trilin_to_cartesian(orbit,[a,b,c],t);
}

function feuerbach_vtx(orbit,sides) {
  let [cA,cB,cC]=tri_cosines(sides);
  let sA=sqrt(1-cA*cA);
  let sB=sqrt(1-cB*cB)
  let sC=sqrt(1-cC*cC);
 
  let f11 = /* -s2[(b-c)/2] = [cos(b-c)-1]/2 */ (cB*cC + sB*sC - 1)/2;
  let f12 = /*  c2[(c-a)/2] = [cos(c-a)+1]/2 */ (cC*cA + sC*sA + 1)/2;
  let f13 = /*  c2[(a-b)/2] = [cos(a-b)+1]/2 */ (cA*cB + sA*sB + 1)/2;
  
  let t = [f11,f12,f13];
  return trilin_to_cartesian(orbit,sides,t);
}

function symmedial_vtx(orbit,[a,b,c]) {
  let t=[0,b,c];
  return trilin_to_cartesian(orbit,[a,b,c],t);
}

function extouch_vtx(orbit,[a,b,c]) {
  let t=[0,(a-b+c)/b,(a+b-c)/c];
  return trilin_to_cartesian(orbit,[a,b,c],t);
}

function medial_vtx(orbit,[a,b,c]) {
  let t=[0,1/b,1/c];
  return trilin_to_cartesian(orbit,[a,b,c],t);
}

function anticompl_vtx(orbit,[a,b,c]) {
  let t=[-1/a,1/b,1/c];
  return trilin_to_cartesian(orbit,[a,b,c],t);
}

function excentral_vtx(orbit,sides) {
  let t=[-1,1,1];
  return trilin_to_cartesian(orbit,sides,t);
}

